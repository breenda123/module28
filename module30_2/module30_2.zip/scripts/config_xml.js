var TSC = TSC || {};

TSC.embedded_config_xml = '<x:xmpmeta tsc:version="2.0.1" xmlns:x="adobe:ns:meta/" xmlns:tsc="http://www.techsmith.com/xmp/tsc/">\
   <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/" xmlns:xmpG="http://ns.adobe.com/xap/1.0/g/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:tscDM="http://www.techsmith.com/xmp/tscDM/" xmlns:tscIQ="http://www.techsmith.com/xmp/tscIQ/" xmlns:tscHS="http://www.techsmith.com/xmp/tscHS/" xmlns:stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#" xmlns:stFnt="http://ns.adobe.com/xap/1.0/sType/Font#" xmlns:exif="http://ns.adobe.com/exif/1.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\
      <rdf:Description dc:date="2024-12-17 10:15:24 PM" dc:source="Camtasia,9.0.4,enu" dc:title="module30_2" tscDM:firstFrame="module30_2_First_Frame.png" tscDM:originId="67823403-5526-4B23-8647-20BF45EAEF59" tscDM:project="module30_2">\
         <xmpDM:duration xmpDM:scale="1/1000" xmpDM:value="100933"/>\
         <xmpDM:videoFrameSize stDim:unit="pixel" stDim:h="904" stDim:w="1418"/>\
         <tsc:langName>\
            <rdf:Bag>\
               <rdf:li xml:lang="en-US">English</rdf:li></rdf:Bag>\
         </tsc:langName>\
         <xmpDM:Tracks>\
            <rdf:Bag>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="Caption" xmpDM:frameRate="f1000" xmpDM:trackName="Captioning" stFnt:fontFamily="Arial" tscDM:fontSize="30" tscDM:bgOpacity="0.750000" tscDM:position="overlay">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:duration="7000" xmpDM:startTime="0" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Đọc từng chiến lược, sau đó nhấp vào chiến lược đó để xem ví dụ về những gì nó \\par có thể nghe như thế nào trong}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="1000" xmpDM:startTime="7000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 luyện tập.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="5000" xmpDM:startTime="8000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Hãy nhớ rằng những chiến lược giao tiếp này không nhất thiết phải diễn ra ở một \\par nơi cụ thể\\par đặt hàng.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="29000" xmpDM:startTime="30000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Nếu bạn sử dụng những chiến lược này, điều quan trọng là phải linh hoạt theo cách \\par tổng quát, và điều đó}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="5000" xmpDM:startTime="59000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 có thể phản xạ và điều chỉnh phong cách giao tiếp tùy theo sở thích của phụ huynh.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="5000" xmpDM:startTime="64000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Ví dụ, nếu bạn gọi điện hoặc gửi email để thảo luận về một vấn đề, một số phụ \\par huynh có thể muốn}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="4000" xmpDM:startTime="69000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Bạn nên đi thẳng vào vấn đề và giải thích vấn đề một cách trực tiếp nhất có thể.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="4000" xmpDM:startTime="73000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Những người khác có thể muốn bạn chia sẻ một số tin tức tích cực về con của họ \\par trước khi bạn thảo luận về điều gì đó}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="2000" xmpDM:startTime="77000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 tiêu cực.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="79000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Bạn có thể điều chỉnh dựa trên quan sát phản ứng bằng lời nói và ngôn ngữ cơ thể \\par của cha mẹ.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="4000" xmpDM:startTime="85000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Bạn cũng có thể chủ động và sử dụng các cuộc khảo sát hoặc gặp gỡ giáo viên vào \\par buổi tối để tìm hiểu sở thích của họ}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="3000" xmpDM:startTime="89000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 vào đầu năm.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="5000" xmpDM:startTime="92000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Để biết thêm các chiến lược tiếp cận phụ huynh, hãy xem mô-đun có tiêu đề Chiến \\par lược}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="1000" xmpDM:startTime="97000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 để thu hút phụ huynh.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                     <tsc:fgColor xmpG:red="255" xmpG:green="255" xmpG:blue="255"/><tsc:bgColor xmpG:red="0" xmpG:green="0" xmpG:blue="0"/></rdf:Description>\
               </rdf:li>\
            </rdf:Bag>\
         </xmpDM:Tracks>\
         <tscDM:controller>\
            <rdf:Description xmpDM:name="tscplayer">\
               <tscDM:parameters>\
                  <rdf:Bag>\
                     <rdf:li xmpDM:name="autohide" xmpDM:value="true"/><rdf:li xmpDM:name="autoplay" xmpDM:value="false"/><rdf:li xmpDM:name="loop" xmpDM:value="false"/><rdf:li xmpDM:name="searchable" xmpDM:value="true"/><rdf:li xmpDM:name="captionsenabled" xmpDM:value="false"/><rdf:li xmpDM:name="sidebarenabled" xmpDM:value="false"/><rdf:li xmpDM:name="unicodeenabled" xmpDM:value="false"/><rdf:li xmpDM:name="backgroundcolor" xmpDM:value="000000"/><rdf:li xmpDM:name="sidebarlocation" xmpDM:value="left"/><rdf:li xmpDM:name="endaction" xmpDM:value="stop"/><rdf:li xmpDM:name="endactionparam" xmpDM:value="true"/><rdf:li xmpDM:name="locale" xmpDM:value="en-US"/></rdf:Bag>\
               </tscDM:parameters>\
               <tscDM:controllerText>\
                  <rdf:Bag>\
                  </rdf:Bag>\
               </tscDM:controllerText>\
            </rdf:Description>\
         </tscDM:controller>\
         <tscDM:contentList>\
            <rdf:Description>\
               <tscDM:files>\
                  <rdf:Seq>\
                     <rdf:li xmpDM:name="0" xmpDM:value="module30_2.mp4"/><rdf:li xmpDM:name="1" xmpDM:value="module30_2.zip"/><rdf:li xmpDM:name="2" xmpDM:value="module30_2_First_Frame.png"/></rdf:Seq>\
               </tscDM:files>\
            </rdf:Description>\
         </tscDM:contentList>\
      </rdf:Description>\
   </rdf:RDF>\
</x:xmpmeta>';
